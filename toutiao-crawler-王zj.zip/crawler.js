const axios = require('axios')
const cheerio = require('cheerio')
const rawJson = require('./test.json')
const fs = require('fs')

const data = [];

(async () => {
  fs.writeFileSync('output.csv', '\uFEFF' + 'title,href,impression_count,comment_count,content\r\n')
  for (let i = 0; i < rawJson.length; i++) {
    const { title, href } = rawJson[i]
    console.log(`[${i + 1}/${rawJson.length}] ${title} ${href}`)
    try {
      const item = await getArticleData(href)
      data.push(item)
      let lineString = `"${item.title.replace(/"/g, '""')}","${href}","${item.impression_count}","${item.comment_count}","${item.content.replace(/"/g, '""')}"\r\n`
      fs.appendFileSync('output.csv', lineString)
    } catch (error) {
      console.log(`【${title}】非头条站内文章，跳过。`)
      continue
    }
  }
  fs.writeFileSync('output.json', JSON.stringify(data))
})()
/**
 * 根据文章url获取文章数据
 *
 * @param {string} url
 * @returns {Promise<{title:string;content:string;impression_count:number;comment_count:number;}>} JSON格式的文章数据
 */
function getArticleData (url) {
  return new Promise((resolve, reject) => {
    axios
      .get(url)
      .then(({ request: { path } }) => {
        return axios.get(`https://m.toutiao.com/i${path.substring(2, path.length - 1)}/info/`)
      })
      .then(({ data: { data } }) => {
        const item = {
          title: data.title.trim(),
          content: cheerio.load(data.content).text().trim(),
          impression_count: Number(data.impression_count),
          comment_count: Number(data.comment_count)
        }
        resolve(item)
      })
      .catch(error => {
        reject(error)
      })
  })
}
