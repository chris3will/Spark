const fs = require('fs')

const posOut = fs
  .readFileSync('./pos_output.txt')
  .toString()
  .split('\r\n')
  .map(lineString => lineString.split('\t'))

const result = posOut
  .map(line =>
    line
      .filter(word =>
        word.includes('_a') ||
        word.includes('_d') ||
        word.includes('_i') ||
        word.includes('_j') ||
        // word.includes('_m') ||
        word.includes('_n') ||
        word.includes('_nh') ||
        word.includes('_ni') ||
        word.includes('_nl') ||
        word.includes('_ns') ||
        word.includes('_nt') ||
        word.includes('_nz') ||
        word.includes('_r') ||
        word.includes('_v') ||
        word.includes('_ws')
      )
      .map(word => word.match(/(^.+)_\w+$/)[1])
      .filter(word => word.length > 1)
  )

// console.log(JSON.stringify(result, null, 2))

const frequency = {}
result.forEach(line => {
  line.forEach(word => {
    if (!frequency[word]) {
      frequency[word] = 1
    } else {
      frequency[word]++
    }
  })
})

Object.entries(frequency).sort((a, b) => b[1] - a[1]).forEach(v => {
  console.log(`${v[0]}\t${v[1]}`)
})
